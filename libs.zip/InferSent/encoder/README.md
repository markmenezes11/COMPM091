# pretrained InferSent model

1. You only need *infersent.pickle* and *models.py* to load infersent.
2. *models.py* contains the model python class.

See example in *demo.ipynb*.
